import subprocess
import os
import random
#Class of the players
class villain():
    def __init__(self, name):
        self.health = 100
        self.energy = 500
        self.name = name 

    def TakeDamage(self, damage):
        self.health -= damage
    
    def ConsumeEnergy(self, energy):
        self.energy -= energy
    
    def __str__(self):
        return f"The villain is {self.fighter} with {self.health} health and {self.energy} energy"
#Class of 
class shield():
    def __init__(self, name, Discribtion, energy, save, resources = 'infinity'):
        self.name = name
        self.__Discribtion = Discribtion
        self.energy = energy
        self.save = save
        self.resources = resources
    def __str__(self):
        return f"Name of shield: {self.name} with {self.energy} energy and reduces {self.save}% of enemy damage and {self.resources} left"
    def DecrementSource(self):
        if(self.resources == 'infinity'):
            raise ValueError("Can't change infinte value")
        else:
            self.resources -= 1
    def Descripe(self):
        print("_____________________________________________________________________")
        print(self.name, "discribtion: ", self.__Discribtion)
        print("_____________________________________________________________________")
    
    def Get_Left(self):
        return self.resources
class Weapon():
    def __init__(self, name, Description, energy, damage, resources = 'infinity'):
        self.name = name
        self.__Description = Description
        self.energy = energy
        self.damage = damage
        self.resources = resources
    def __str__(self):
        return f"Name of weapon: {self.name} with {self.energy} energy and  {self.damage} damage and {self.resources} left"
    def Descripe(self):
        print("_____________________________________________________________________")
        print(self.name, "discribtion: ",self.__Description)
        print("_____________________________________________________________________")
    
    def DecrementSource(self):
        if(self.resources == 'infinity'):
            raise ValueError("Can't change infinte value")
        else:
            self.resources -= 1
        
    def Get_Left(self):
        return self.resources

#Function to clear the terminal for better visibilty
def clear_terminal():
    subprocess.call("clear" if os.name == "posix" else "cls", shell=True)
#Fucntion to check if the input is integer
def CheckIfInteger(prompt):
    while True:
        try:
            value = int(input(prompt))
            return value
        except ValueError:
            print("Please enter a valid integer.")

##Gru's weapons
FreezeGun = Weapon("Freeze Gun","Minions occasionally wield freeze ray guns that shoot a freezing beam to immobilize opponents temporarily.", 50, 11)
ElectricProd = Weapon("Electric Prod", "Minions might use electric prods to deliver mild shocks to enemies, stunning them momentarily.", 88, 18, 5)
MegaMagnet = Weapon("Mega Magnet", "Minions utilize a mega magnet to attract or repel metal objects, potentially disrupting enemy vehicles or equipment.", 92, 10, 3)
KalmanMissile = Weapon("Kalman Missile", "This unavoidable Missile created for enourmous distraction", 120, 20, 1)
##Vector's weapons
LaserBlasters = Weapon("Laser Blasters", "Vector's primary weapon would be powerful laser blasters attached to his flying pod. These blasters emit focused energy beams that can slice through obstacles and damage enemy vehicles.", 40, 8)
PlasmaGrenades = Weapon("Plasma Grenades", "Vector could use plasma grenades that explode on impact, releasing fiery energy bursts that deal significant damage to enemy vehicles caught in the blast radius.", 56, 13, 8)
SonicResonanceCannon = Weapon("Sonic Resonance Cannon", "Fires powerful sonic waves that can shatter enemy shields and disrupt their systems, temporarily incapacitating them.", 100, 22, 3)

##Gru's shields
EnergyProjectedBarrierGun = shield("Energy Projected Barrier Gun", "The spaceship's shields create an invisible, energy-projected barrier around the vehicle. This barrier absorbs and dissipates energy- based attacks such as lasers, beams, and plasma shots.", 20, .4)
SelectivePermeability = shield("Selective Permeability", "The shields can be programmed to allow certain objects, signals, or energies to pass through while blocking others. This can be useful for communication or specific tactical maneuvers.", 50, .9, 2)
##Vector's shields
EnergyNetTrap = shield("Energy Net Trap", "Vector's pod might have the ability to deploy an energy net that ensnares enemy vehicles, temporarily immobilizing them and leaving them vulnerable to Vector's other attacks.", 15, .32)
QuantumDeflector = shield("Quantum Deflector", "Manipulates quantum states to create a deflection field, causing enemy projectiles to miss the spaceship by a slight margin in the quantum realm.", 40, .8, 3)


clear_terminal()
#Display describtion of weapons and shields
print("Let's get to know about the weapons and shlieds you will use in the game")
while 1:
    #Display names of the weapons and shilds
    print("Weapons:\n1)Freeze Gun\n2)Electric prod\n3)Mega Magnet\n4)Kalman Missile\n5)Laser Blasters\n6)Plasma Grenades\n7)Sonic Resonance Cannon")
    print("Shields:")
    print("8)Energy Projected Barrier Gun\n9)Selective Permeability\n10)Energy Net Trap\n11)Quantum Deflector")
    print("12)Sart game")
    option = CheckIfInteger("Choose one to show describtion ")
    #Display the describtion of the choosen one
    if option == 1:
        clear_terminal()
        FreezeGun.Descripe()
    elif option == 2:
        clear_terminal()
        ElectricProd.Descripe()
    elif option == 3:
        clear_terminal()
        MegaMagnet.Descripe()
    elif option == 4:
        clear_terminal()
        KalmanMissile.Descripe()
    elif option == 5:
        clear_terminal()
        LaserBlasters.Descripe()
    elif option == 6:
        clear_terminal()
        PlasmaGrenades.Descripe()
    elif option == 7:
        clear_terminal()
        SonicResonanceCannon.Descripe()
    elif option == 8:
        clear_terminal()
        EnergyProjectedBarrierGun.Descripe()
    elif option == 9:
        clear_terminal()
        SelectivePermeability.Descripe()
    elif option == 10:
        clear_terminal()
        EnergyNetTrap.Descripe()
    elif option == 11:
        clear_terminal()
        QuantumDeflector.Descripe()
    elif option == 12:
        break
    else:
        clear_terminal()
        print("Enter a valid input\n")

clear_terminal()

#Get number of players
print("Please expand this screen to its fullest")
print("1)One Player\n2)Two player")
Number = CheckIfInteger("Enter number of players: ")
while 1:
    if Number == 1:
        #If one player get only one name
        name = input("Enter the Name of the player: ")
        Gru = villain(name)
        Vector = villain("Computer")
        break
    elif Number == 2:
        #If two players get both of their name
        name1 = input("Enter the name of first player: ")
        Gru = villain(name1)
        name2 = input("Enter the name of the second player: ")
        Vector = villain(name2)
        break
    else:
        print("Enter valid input")

#Players function that determine which weapon or shield is choosen and its effects
#First player's function
def Gru_Select():
    Debug = 0
    while Debug <= 0:
        #Get player's choice
        option = CheckIfInteger("Enter your choice ")
        #Initialize variables with zero
        damage = 0
        energy = 0
        save = 0
        left = 0
        Debug = 0
        special = 0
        if option == 1:
            #Get the damage and energy of the weapon
            damage = FreezeGun.damage
            energy = FreezeGun.energy
            #Check if player's energy is enough
            if energy > Gru.energy:
                print("You don't have enough energy to use this weapon, try again")
                continue
            else:
                Debug = 1
        elif option == 2:
            damage = ElectricProd.damage
            energy = ElectricProd.energy
            left = ElectricProd.Get_Left()
            #Check the resources of the weapon
            if left <1:
                print("You ran out of this weapon, try again")
                continue
            elif energy > Gru.energy:
                print("You don't have enough energy to use this weapon, try again")
                continue
            else:
                Debug = 1
            #Decrement the resources by one
            ElectricProd.DecrementSource()
        elif option == 3:
            damage = MegaMagnet.damage
            energy = MegaMagnet.energy
            left = MegaMagnet.Get_Left()
            if left <1:
                print("You ran out of this weapon, try again")
                continue
            elif energy > Gru.energy:
                print("You don't have enough energy to use this weapon, try again")
                continue
            else:
                Debug = 1
                special = 2
            MegaMagnet.DecrementSource()

        elif option == 4:
            damage = KalmanMissile.damage
            energy = KalmanMissile.energy
            left = KalmanMissile.Get_Left()
            if left <1:
                print("You ran out of this weapon, try again")
                continue
            elif energy > Gru.energy:
                print("You don't have enough energy to use this weapon, try again")
                continue
            else:
                Debug = 1
                special = 1
            KalmanMissile.DecrementSource()
        elif option == 5:
            energy = EnergyProjectedBarrierGun.energy
            #Get the effect of the shield
            save = EnergyProjectedBarrierGun.save
            if energy > Gru.energy:
                print("You don't have enough energy to use this Shield, try again")
                continue
            else:
                Debug = 1
        elif option == 6:
            energy =SelectivePermeability.energy
            save = SelectivePermeability.save
            left = SelectivePermeability.Get_Left()
            if left <1:
                print("You ran out of this weapon, try again")
                continue
            elif energy > Gru.energy:
                print("You don't have enough energy to use this weapon, try again")
                continue
            else:
                Debug = 1
            SelectivePermeability.DecrementSource()
        else:
            print("Enter valid input")
            continue
    #Return the required variables
    return damage,energy,save,special
#Second player's function
def Vector_Select():
    Debug = 0
    while Debug <= 0:
        #Check if one player or two
        if Number == 1:
            #If one player create random choice
            option = random.randint(1,5)
        elif Number == 2:
            #If Two players get their choice
            option = CheckIfInteger("Enter your choice ")
        damage = 0
        energy = 0
        save = 0
        left = 0
        Debug = 0
        if option == 1:
            damage = LaserBlasters.damage
            energy = LaserBlasters.energy
            if energy > Vector.energy:
                print("You don't have enough energy to use this weapon, try again")
                continue
            else:
                Debug = 1
            if Number == 1:
                print("Your opponent chose Laser Blasters")
        elif option == 2:
            damage = PlasmaGrenades.damage
            energy = PlasmaGrenades.energy
            left = PlasmaGrenades.Get_Left()
            if left <1:
                print("You ran out of this weapon, try again")
                continue
            elif energy > Vector.energy:
                print("You don't have enough energy to use this weapon, try again")
                continue
            else:
                Debug = 1
            PlasmaGrenades.DecrementSource()
            if Number == 1:
                print("Your opponent chose Plasma Grenades")
        elif option == 3:
            damage = SonicResonanceCannon.damage
            energy = SonicResonanceCannon.energy
            left = SonicResonanceCannon.Get_Left()
            if left <1:
                print("You ran out of this weapon, try again")
                continue
            elif energy > Vector.energy:
                print("You don't have enough energy to use this weapon, try again")
                continue
            else:
                Debug = 1
            SonicResonanceCannon.DecrementSource()
            if Number == 1:
                print("Your opponent chose Sonic Resonance Cannon")
        elif option == 4:
            energy = EnergyNetTrap.energy
            save = EnergyNetTrap.save
            if energy > Vector.energy:
                print("You don't have enough energy to use this Shield, try again")
                continue
            else:
                Debug = 1
            if Number == 1:
                print("Your opponent chose Consume Energy")
        elif option == 5:
            energy =QuantumDeflector.energy
            save = QuantumDeflector.save
            left = QuantumDeflector.Get_Left()
            if left <1:
                print("You ran out of this weapon, try again")
                continue
            elif energy > Vector.energy:
                print("You don't have enough energy to use this weapon, try again")
                continue
            else:
                Debug = 1
            QuantumDeflector.DecrementSource()
            if Number == 1:
                print("Your opponent chose Quantum Deflector")
        else:
            print("Enter valid input")
            continue
    return damage,energy,save




#Variable that holds the number of rounds
Round = 0

#MAIN GAME
while 1:
    #Increment round variable
    Round += 1
    clear_terminal()
    #Display players stats
    print(Gru.name,"'s health: ",f"{Gru.health:.2f}",", Energy: ",Gru.energy)
    print(Vector.name,"'s health: ",f"{Vector.health:.2f}",", Energy: ",Vector.energy)
    print("___________________________________________________________")
    #Display round number and player's turn
    print("Round ",Round,"||",Gru.name,"'s turn, Choose the number of weapon or shield you want to use: ")
    #Display available weapons and shileds
    print("Weapons:")
    print("1)Freeze Gun\n\t|Damage: ",FreezeGun.damage,"\n\t|Consumes",FreezeGun.energy,"energy","\n\t|Infinite uses")
    print("2)Electric Prod\n\t|Damage: ",ElectricProd.damage,"\n\t|Consumes",ElectricProd.energy,"energy","\n\tRemainig: ",ElectricProd.resources)
    print("3)Mega Magnet (Reduce 20% of the next attack)\n\t|Damage: ",MegaMagnet.damage ,"\n\t|Consumes",MegaMagnet.energy,"energy","\n\t|Remaining: ", MegaMagnet.resources)
    print("4)Kalman missile (Can't be avoided)\n\t|Damage: ",KalmanMissile.damage,"\n\t|Consumes",KalmanMissile.energy,"energy","\n\t|Remainig: ",KalmanMissile.resources)
    print("Shields:")
    print("5)Enrgy Projected Barrier Gun\n\t|Saves: ",100 * EnergyProjectedBarrierGun.save ,"%","\n\t|Consumes", EnergyProjectedBarrierGun.energy,"energy", "\n\t|Infinte uses")
    print("6)Selective Permeability \n\t|Saves: ",100 * SelectivePermeability.save,"%","\n\t|Consumes", SelectivePermeability.energy,"energy", "\n\t|Remaining: ",SelectivePermeability.resources)
    
    #Call first player function
    damage_Gru,energy_Gru,sav_Gru,special = Gru_Select()
    
    #Check whether one or two players
    if Number == 2:
        #If two players display option for the second one
        clear_terminal()
        print(Gru.name,"'s health: ",f"{Gru.health:.2f}",", Energy: ",Gru.energy)
        print(Vector.name,"'s health: ",f"{Vector.health:.2f}",", Energy: ",Vector.energy)
        print("___________________________________________________________")
        print("Round",Round,"||",Vector.name,"'s turn, choose the number of weapon or shield you want to use: ")
        print("Weapons:")
        print("1)Laser Blaster\n\t|Damage: ",LaserBlasters.damage,"\n\t|Consumes",LaserBlasters.energy,"energy","\n\t|Infinite uses")
        print("2)Plasma Grenades\n\t|Damage: ",PlasmaGrenades.damage,"\n\t|Consumes",PlasmaGrenades.energy,"energy","\n\t|Remainig: ",PlasmaGrenades.resources)
        print("3)Sonic Resonance\n\t|Damage: ",SonicResonanceCannon.damage,"\n\t|Consumes",SonicResonanceCannon.energy,"energy","\n\t|Remainig: ",SonicResonanceCannon.resources)
        print("Shields:")
        print("4)Energy net Trap\n\t|Saves: ",100 * EnergyNetTrap.save,"%","\n\t|Consumes", EnergyNetTrap.energy,"energy", "\n\t|Infinte uses")
        print("5)Quantum Deflector\n\t|Saves: ",100 * QuantumDeflector.save,"%","\n\t|Consumes", QuantumDeflector.energy,"energy", "\n\t|Remaining: ",QuantumDeflector.resources)

    #Call second player's function
    damage_Vec,energy_Vec,sav_Vec = Vector_Select()
    
    #Special effects of some weapons
    if special == 1:##Kalman missile effect
        sav_Vec = 0
    elif special == 2:##Mega magnet effect
        damage_Vec *=.8

    #Update the energy and heatlth of the players 
    Gru.ConsumeEnergy(energy_Gru)
    Vector.ConsumeEnergy(energy_Vec)
    Vector.TakeDamage(damage_Gru * (1 - sav_Vec))
    Gru.TakeDamage(damage_Vec * (1 - sav_Gru))
    
    
    print("___________________________________________________________")
    #Check health and energy of players
    #If still enough to continue then continue otherwise announe the winner
    if Gru.health <= 0:
        if Number == 2:
            print(Gru.name," Died")
            print("CONGRATULATIONS",Vector.name,".You won :)")
        elif Number == 1:
            print("YOU DIED :(")
        break
    elif Vector.health <= 0:
        if Number == 2:
            print(Vector.name," Died")
            print("CONGRATULATIONS",Gru.name,".You won :)")
        elif Number == 1:
            print("YOU WON :)\nYour opponent DIED")
        break
    elif Gru.energy < EnergyProjectedBarrierGun.energy:
        if Number == 2:
            print(Gru.name,"ran out of energy\nCONGRATULATIONS",Vector.name,".You won :)")
        elif Number == 1:
            print("YOU LOST :(\nYou ran out of energy")
        break
    elif Vector.energy < EnergyNetTrap.energy:
        if Number == 2:
            print(Vector.name," ran out of energy")
            print("CONGRATULATIONS",Gru.name,".You won :)") 
        elif Number == 1:
            print("YOU WON :)\nYour opponent ran out of energy")
        break
    else:
        #If only one player is playing, announce the move made by the computer
        if Number == 1:
            input("Press any key to continue")